package com.example.carrompoollauncher

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Draggable floating launcher panel.
 * Tap the compact bubble to expand/collapse the feature menu.
 * The listed switches are UI placeholders only; they do not modify Carrom Pool gameplay.
 */
class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private var expanded = false
    private var menu: LinearLayout? = null
    private var bubble: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (root == null) createPanel()
        return START_NOT_STICKY
    }

    private fun createPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(180)
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = rounded(0xEE20242B.toInt(), dp(14).toFloat())
        }
        root = container

        val handle = TextView(this).apply {
            text = "◉  Carrom"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(0xFF3B4655.toInt(), dp(12).toFloat())
        }
        bubble = handle
        container.addView(handle)
        handle.setOnClickListener { toggleExpanded() }
        handle.setOnTouchListener(DragTouchListener(handle))

        val featureMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }
        menu = featureMenu
        container.addView(featureMenu)
        buildMenu(featureMenu)
        featureMenu.visibility = View.GONE
        wm.addView(container, params)
    }

    private fun buildMenu(target: LinearLayout) {
        target.addView(TextView(this).apply {
            text = "Feature panel"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(6), dp(4), dp(6), dp(8))
        })

        // Safe, local UI toggles. These are placeholders and do not affect gameplay.
        val featureNames = listOf(
            "Feature 1", "Feature 2", "Feature 3",
            "Feature 4", "Feature 5", "Feature 6"
        )
        featureNames.forEach { name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(this).apply {
                text = name
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(dp(6), dp(7), dp(12), dp(7))
            }
            val toggle = Button(this).apply {
                text = "OFF"
                isAllCaps = false
                setOnClickListener {
                    val isOn = text.toString() != "ON"
                    text = if (isOn) "ON" else "OFF"
                    // Placeholder state only; no game memory/internals are changed.
                }
            }
            row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(toggle)
            target.addView(row)
        }

        target.addView(Button(this).apply {
            text = "Close panel"
            isAllCaps = false
            setOnClickListener { stopSelf() }
        })
    }

    private fun toggleExpanded() {
        expanded = !expanded
        menu?.visibility = if (expanded) View.VISIBLE else View.GONE
        bubble?.text = if (expanded) "◉  Carrom  ▾" else "◉  Carrom"
        root?.let { wm.updateViewLayout(it, params) }
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private inner class DragTouchListener(private val handle: View) : View.OnTouchListener {
        private var downRawX = 0f
        private var downRawY = 0f
        private var initialX = 0
        private var initialY = 0
        private var moved = false

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    initialX = params.x
                    initialY = params.y
                    moved = false
                    return false // allow click when the user taps without dragging
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    if (moved) {
                        params.x = (initialX + dx).coerceAtLeast(0)
                        params.y = (initialY + dy).coerceAtLeast(0)
                        root?.let { wm.updateViewLayout(it, params) }
                        return true
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) return true
            }
            return false
        }
    }

    override fun onDestroy() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        super.onDestroy()
    }
}
