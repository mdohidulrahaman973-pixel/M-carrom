package com.example.carrompoollauncher

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "Carrom Pool Launcher"
            textSize = 24f
            gravity = Gravity.CENTER
        })
        layout.addView(TextView(this).apply {
            text = "Opens the installed game and optionally shows a harmless movable panel."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        })

        layout.addView(Button(this).apply {
            text = "Open Carrom Pool"
            setOnClickListener { openCarromPool() }
        })
        layout.addView(Button(this).apply {
            text = "Enable floating panel"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                    Toast.makeText(this@MainActivity, "Allow display over other apps, then return and tap again.", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, FloatingPanelService::class.java))
                    Toast.makeText(this@MainActivity, "Floating panel started.", Toast.LENGTH_SHORT).show()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Open game + panel"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, FloatingPanelService::class.java))
                    openCarromPool()
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    Toast.makeText(this@MainActivity, "Allow overlay permission, then tap again.", Toast.LENGTH_LONG).show()
                }
            }
        })
        setContentView(layout)
    }

    private fun openCarromPool() {
        val launchIntent = packageManager.getLaunchIntentForPackage("com.miniclip.carrom")
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Carrom Pool was not found. Install the official game first or update its package name in MainActivity.kt.", Toast.LENGTH_LONG).show()
        }
    }
}
