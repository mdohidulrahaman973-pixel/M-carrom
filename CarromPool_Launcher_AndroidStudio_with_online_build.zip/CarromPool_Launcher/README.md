# Carrom Pool Launcher (starter project)

This Android Studio project launches the official Carrom Pool app if installed and can show a draggable floating panel. The six feature switches are UI placeholders only; they do not change gameplay.

## Build with Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync finish.
3. Select **Build > Build APK(s)**.
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Build online with GitHub Actions
1. Upload this project folder to a GitHub repository.
2. Open the repository's **Actions** tab and run **Build Android APK** (or push a commit).
3. When the workflow succeeds, open that run and download the `CarromPool-Launcher-debug-apk` artifact.
4. Extract the artifact to get `app-debug.apk`.

## Important notes
- This is source code, not a prebuilt APK. The APK must be built first.
- The game package is currently set to `com.miniclip.carrom` in `MainActivity.kt` and `AndroidManifest.xml`. If the official game on your phone uses a different package ID, the launcher button will not find it.
- Android requires permission to display over other apps before the floating panel can appear.
- This project does not bypass login, licensing, anti-cheat, or game security and does not include cheats or gameplay modification.
- The project has not been compiled or device-tested in this environment.
